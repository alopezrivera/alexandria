def if_none(a, b):
    return b if isinstance(a, type(None)) else a
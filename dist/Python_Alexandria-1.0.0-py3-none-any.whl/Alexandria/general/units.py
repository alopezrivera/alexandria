import numpy as np


def deg(a):
    return a/np.pi*180


def rad(a):
    return a/180*np.pi